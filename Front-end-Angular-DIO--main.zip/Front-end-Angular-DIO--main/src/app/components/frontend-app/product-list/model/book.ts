export class book
{
    id!: string;
    name!: string;
    price!: number;
    quantity!: number;
    category!: string;
    img!: string;


}