import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontend-app',
  templateUrl: './frontend-app.component.html',
  styleUrls: ['./frontend-app.component.css']
})
export class FrontendAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
